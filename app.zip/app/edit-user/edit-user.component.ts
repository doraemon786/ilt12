import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { User } from 'src/model/user.model';
import {first} from 'rxjs/operators';


@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  editForm : FormGroup;
  submitted: boolean=false;
  user:User;

  constructor(private fromBuilder: FormBuilder,private router:Router,private userService:UserService) { }

  ngOnInit() {
    if(localStorage.getItem("username")!=null){
      let userId = localStorage.getItem("editUserId");
      if(!userId){
        alert('Invalid Action');
        this.router.navigate(['/list-user']);
        return;
      }
      this.editForm = this.fromBuilder.group({
        id:[],
      firstName:['',Validators.required],
      lastName:['',Validators.required],
      email:['',Validators.required],

      });
      this.editForm.userService.getUsersById(+userId)
      .subscribe(data=>{
        this.editForm.setValue(data)
      });
    }
    else{
      this.router.navigate(['/login']);
    }
  }

  onSubmit(){
     this.submitted  = true;
     if(this.editForm.invalid){
       return;
     }
     this.userService.updateUsers(this.editForm.value).pipe(first()).subscribe(data=>{
     
      this.router.navigate(['/list-user']);
    },error=>{
      alert(error);
    });

}
// LogOff
logOutUser(){
  if (localStorage.getItem("username")!=null){
    localStorage.removeItem("username");
    this.router.navigate(['/login']);

  } 

}

}