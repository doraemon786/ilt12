import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from 'src/model/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  //dependency injection -injecting built in http server 
  //inside constructor
  constructor(private http:HttpClient) {}
    baseUrl:string="http://localhost:3000/users";
  //get all user
  getUsers()
  {
 return this.http.get<User[]>(this.baseUrl);
  }
  //get user by id
  getUsersById(id:number)
  {
 return this.http.get<User[]>(this.baseUrl+"/"+id);
  }
  createUsers(user:User)
  {
 return this.http.post(this.baseUrl,user);
  }
// modify user by id

updateUsers(user:User)
{
  return this.http.put(this.baseUrl+"/"+user.id,user);
}

// delete user by id

deleteUsers(id:number)
{
  return this.http.delete(this.baseUrl+"/"+id);
}
}
