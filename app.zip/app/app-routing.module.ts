import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginUserComponent } from './login-user/login-user.component';
import { HomeComponent } from './home/home.component';
import { AddUserComponent } from './add-user/add-user.component';
import { ListUserComponent } from './list-user/list-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';

const routes: Routes = [
  {path: 'login',component:LoginUserComponent},
  {path: 'home',component:HomeComponent},
  {path: 'add-user',component:AddUserComponent},
  {path: 'list-user',component:ListUserComponent},
  {path: 'edit-user',component:EditUserComponent},
  {path: '',component:HomeComponent},
  //or
 // {path: '',redirectTo:'/home',pathMatch:'full'},
  {path: '**',component:HomeComponent},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
