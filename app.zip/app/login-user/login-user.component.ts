import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {
// Instance Variables by deafault public in TS
  loginForm: FormGroup;
  submitted: boolean = false;
  invalidLogin: boolean = false; 

  constructor(private formBuilder : FormBuilder,private router:Router) { }
  onSubmit(){
    this.submitted = true;
    //if validatiion fails it should return to validate again
    if(this.loginForm.invalid)
    {
      return;
    }
    let username = this.loginForm.controls.email.value;
    if(this.loginForm.controls.email.value == "saurav9a@gmail.com" 
              && this.loginForm.controls.password.value =="123456"){
                localStorage.setItem("username",username);
                this.router.navigate(['/list-user']);
              }
              else{
                this.invalidLogin = true;   
              }
  }
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email:['',Validators.required],
      password:['',Validators.required]
    });
  }

}
